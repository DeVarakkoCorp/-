package dev.aether.client.game;

public enum GameKey {
    W, A, S, D, Q, E, SPACE, LEFT, RIGHT, UP, DOWN, EQUAL, MINUS, DIGIT_1, DIGIT_2,
    DIGIT_3, DIGIT_4, DIGIT_5, DIGIT_6, DIGIT_7, DIGIT_8, DIGIT_9
}
