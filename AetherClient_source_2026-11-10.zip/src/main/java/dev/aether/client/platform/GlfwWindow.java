package dev.aether.client.platform;

import org.lwjgl.glfw.GLFWFramebufferSizeCallback;
import org.lwjgl.glfw.GLFWCursorPosCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallback;
import org.lwjgl.glfw.GLFWKeyCallback;
import org.lwjgl.glfw.GLFWWindowSizeCallback;
import dev.aether.client.game.GameInputState;
import dev.aether.client.game.GameKey;
import dev.aether.client.game.MouseButton;

import java.util.HashSet;
import java.util.Set;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.system.MemoryUtil.NULL;

public final class GlfwWindow implements AutoCloseable, GameInputState {
    private final int width;
    private final int height;
    private final String title;
    private long handle;
    private int framebufferWidth;
    private int framebufferHeight;
    private GLFWFramebufferSizeCallback framebufferCallback;
    private GLFWCursorPosCallback cursorCallback;
    private GLFWMouseButtonCallback mouseButtonCallback;
    private GLFWKeyCallback keyCallback;
    private GLFWWindowSizeCallback windowSizeCallback;
    private final Set<Integer> pressedKeys = new HashSet<>();
    private final Set<Integer> keyPressEvents = new HashSet<>();
    private final Set<Integer> pressedMouseButtons = new HashSet<>();
    private final Set<Integer> mousePressEvents = new HashSet<>();
    private double cursorX;
    private double cursorY;
    private int windowWidth;
    private int windowHeight;

    public GlfwWindow(int width, int height, String title) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Window dimensions must be positive");
        }
        this.width = width;
        this.height = height;
        this.windowWidth = width;
        this.windowHeight = height;
        this.title = title;
    }

    public void create() {
        if (handle != NULL) {
            throw new IllegalStateException("Window already created");
        }

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
        glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        long created = glfwCreateWindow(width, height, title, NULL, NULL);
        if (created == NULL) {
            throw new IllegalStateException("Failed to create GLFW window");
        }

        handle = created;
        int[] w = new int[1];
        int[] h = new int[1];
        glfwGetFramebufferSize(handle, w, h);
        framebufferWidth = w[0];
        framebufferHeight = h[0];

        framebufferCallback = GLFWFramebufferSizeCallback.create((window, newWidth, newHeight) -> {
            framebufferWidth = newWidth;
            framebufferHeight = newHeight;
        });
        glfwSetFramebufferSizeCallback(handle, framebufferCallback);
        windowSizeCallback = GLFWWindowSizeCallback.create((window, newWidth, newHeight) -> {
            windowWidth = newWidth;
            windowHeight = newHeight;
        });
        glfwSetWindowSizeCallback(handle, windowSizeCallback);
        cursorCallback = GLFWCursorPosCallback.create((window, x, y) -> {
            cursorX = x;
            cursorY = y;
        });
        glfwSetCursorPosCallback(handle, cursorCallback);
        mouseButtonCallback = GLFWMouseButtonCallback.create((window, button, action, mods) -> {
            if (action == GLFW_PRESS) {
                pressedMouseButtons.add(button);
                mousePressEvents.add(button);
            } else if (action == GLFW_RELEASE) {
                pressedMouseButtons.remove(button);
            }
        });
        glfwSetMouseButtonCallback(handle, mouseButtonCallback);

        keyCallback = GLFWKeyCallback.create((window, key, scancode, action, mods) -> {
            if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
                glfwSetWindowShouldClose(window, true);
            }
            if (action == GLFW_PRESS) {
                pressedKeys.add(key);
                keyPressEvents.add(key);
            }
            if (action == GLFW_RELEASE) pressedKeys.remove(key);
        });
        glfwSetKeyCallback(handle, keyCallback);
    }

    public long handle() {
        ensureCreated();
        return handle;
    }

    public boolean shouldClose() {
        ensureCreated();
        return glfwWindowShouldClose(handle);
    }

    public int framebufferWidth() {
        return framebufferWidth;
    }

    public int framebufferHeight() {
        return framebufferHeight;
    }

    public boolean isKeyDown(int key) {
        return pressedKeys.contains(key);
    }

    @Override
    public boolean keyDown(GameKey key) {
        return isKeyDown(glfwKey(key));
    }

    @Override
    public boolean mouseDown(MouseButton button) {
        return isMouseButtonDown(glfwMouseButton(button));
    }

    @Override
    public boolean consumeKeyPress(GameKey key) {
        return keyPressEvents.remove(glfwKey(key));
    }

    public boolean consumeMousePress(int button) {
        return mousePressEvents.remove(button);
    }

    @Override
    public boolean consumeMousePress(MouseButton button) {
        return consumeMousePress(glfwMouseButton(button));
    }

    public boolean isMouseButtonDown(int button) {
        return pressedMouseButtons.contains(button);
    }

    public double cursorX() { return cursorX; }
    public double cursorY() { return cursorY; }
    public int windowWidth() { return windowWidth; }
    public int windowHeight() { return windowHeight; }

    public void setTitle(String title) {
        ensureCreated();
        glfwSetWindowTitle(handle, java.util.Objects.requireNonNull(title, "title"));
    }

    private static int glfwKey(GameKey key) {
        return switch (java.util.Objects.requireNonNull(key, "key")) {
            case W -> GLFW_KEY_W;
            case A -> GLFW_KEY_A;
            case S -> GLFW_KEY_S;
            case D -> GLFW_KEY_D;
            case Q -> GLFW_KEY_Q;
            case E -> GLFW_KEY_E;
            case SPACE -> GLFW_KEY_SPACE;
            case LEFT -> GLFW_KEY_LEFT;
            case RIGHT -> GLFW_KEY_RIGHT;
            case UP -> GLFW_KEY_UP;
            case DOWN -> GLFW_KEY_DOWN;
            case EQUAL -> GLFW_KEY_EQUAL;
            case MINUS -> GLFW_KEY_MINUS;
            case DIGIT_1 -> GLFW_KEY_1;
            case DIGIT_2 -> GLFW_KEY_2;
            case DIGIT_3 -> GLFW_KEY_3;
            case DIGIT_4 -> GLFW_KEY_4;
            case DIGIT_5 -> GLFW_KEY_5;
            case DIGIT_6 -> GLFW_KEY_6;
            case DIGIT_7 -> GLFW_KEY_7;
            case DIGIT_8 -> GLFW_KEY_8;
            case DIGIT_9 -> GLFW_KEY_9;
        };
    }

    private static int glfwMouseButton(MouseButton button) {
        return switch (java.util.Objects.requireNonNull(button, "button")) {
            case LEFT -> GLFW_MOUSE_BUTTON_LEFT;
            case RIGHT -> GLFW_MOUSE_BUTTON_RIGHT;
            case MIDDLE -> GLFW_MOUSE_BUTTON_MIDDLE;
        };
    }

    private void ensureCreated() {
        if (handle == NULL) {
            throw new IllegalStateException("Window is not created");
        }
    }

    @Override
    public void close() {
        if (handle == NULL) {
            return;
        }
        glfwSetFramebufferSizeCallback(handle, null);
        glfwSetKeyCallback(handle, null);
        if (framebufferCallback != null) {
            framebufferCallback.free();
            framebufferCallback = null;
        }
        if (cursorCallback != null) {
            cursorCallback.free();
            cursorCallback = null;
        }
        if (mouseButtonCallback != null) {
            mouseButtonCallback.free();
            mouseButtonCallback = null;
        }
        if (keyCallback != null) {
            keyCallback.free();
            keyCallback = null;
        }
        if (windowSizeCallback != null) {
            windowSizeCallback.free();
            windowSizeCallback = null;
        }
        glfwDestroyWindow(handle);
        handle = NULL;
    }
}
