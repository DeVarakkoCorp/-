# Architecture notes

## Current bootstrap flow

`AetherLauncher` owns GLFW initialization and the lifetime of the application. `GlfwWindow` creates a window and current OpenGL context. `OpenGLRenderer` owns the test shader, VAO and VBO. The main loop polls events, renders and swaps buffers.

## Threading contract

The initial OpenGL implementation is single-render-thread. All GLFW window operations and all `gl*` calls occur on the thread that created the context. CPU workers may be added later, but must not call OpenGL directly.

## Resource ownership

`GlResourceRegistry` is a render-thread-confined owner for `AutoCloseable` GPU objects. It closes resources in reverse registration order and aggregates cleanup failures. A production implementation will need explicit dependency edges and more detailed diagnostics.

## Render target

`OpenGLRenderTarget` owns one framebuffer, one RGBA8 color texture and one DEPTH_COMPONENT24 texture. Resize allocates and validates a replacement framebuffer before deleting the previous target. It restores the previously bound framebuffer (or binds the replacement if the old target was bound).

## Shader loading

`ShaderSourceLoader` resolves classpath resources under `assets/aether/shaders`. Includes are relative to the including file. Paths escaping the shader root are rejected. A source may contain one root `#version` directive; included files may not declare one. `#line` directives are inserted around included text to improve compiler diagnostics.

## Planned next stages

1. Harden lifecycle with integration tests on a real GL context.
2. Add texture upload and typed uniform APIs.
3. Introduce render graph resource read/write dependencies.
4. Add chunk/world data structures and worker scheduling.
5. Add Vulkan as a separate backend behind the rendering API.
6. Add a documented mod API and compatibility adapters.
