rootProject.name = "AetherClient"
