# Aether Client — bootstrap project

**Target:** Minecraft Java Edition 1.20.6-inspired independent client architecture  
**Runtime:** Java 21, LWJGL 3.3.3, OpenGL 3.3 Core  
**Status:** bootstrap vertical slice, not a complete Minecraft-compatible client.

This archive contains a real Gradle project with Java sources, resources, unit tests and documentation. It is the first reproducible foundation for Aether Client—not a finished game client and not a drop-in replacement for Minecraft.

## Implemented in this bootstrap

- GLFW window creation and orderly shutdown.
- OpenGL 3.3 core context creation.
- Basic game/render loop.
- OpenGL shader compilation and linking with cleanup on failure.
- Triangle rendering through VAO/VBO.
- Render-target/framebuffer with color and depth textures, completeness validation and transactional resize.
- Render-thread-confined resource registry.
- Classpath shader loader with nested includes, cycle detection, traversal protection and `#line` markers.
- JUnit tests for shader source loading and render-target dimension validation.

## Not implemented yet

- Minecraft protocol/client gameplay and world simulation.
- Chunk storage, meshing, lighting and streaming.
- Vulkan backend.
- Fabric/Forge compatibility.
- Full render graph and shader hot reload.
- Audio, UI, physics and mod runtime.
- Performance claims on the target Huawei laptop.

## Requirements

- Windows 10/11 x64 (the default native classifier is Windows).
- JDK 21.
- Gradle 8.7 or newer installed and available as `gradle`.
- A graphics driver supporting OpenGL 3.3.

## Build and test

Open PowerShell in this directory:

```powershell
java -version
gradle --version
gradle clean test
gradle run
```

The first Gradle invocation downloads dependencies from Maven Central. A working internet connection is required.

To build the application JAR:

```powershell
gradle clean build
```

The JAR is written to `build/libs/`.

### Other operating systems

Override the LWJGL native classifier:

```powershell
gradle -PlwjglNatives=natives-windows test
```

Linux: `natives-linux`; macOS Intel: `natives-macos`; macOS Apple Silicon: `natives-macos-arm64`.

## Project layout

```text
AetherClient/
├── src/main/java/dev/aether/client/
│   ├── launcher/
│   ├── platform/
│   ├── rendering/
│   ├── rendering/opengl/
│   └── resources/
├── src/main/resources/assets/aether/shaders/
├── src/test/java/dev/aether/client/
├── docs/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

This first archive intentionally uses one Gradle module. Splitting into many Gradle subprojects before the API boundaries and dependency direction are validated would create extra build complexity. The package boundaries are the starting point for a later multi-project split.

## Clean-room policy

Aether Client is being developed as an independent implementation. This repository does not include Mojang source code or proprietary game assets. Do not copy decompiled Minecraft code or redistribute game assets without permission. Official game data must be obtained through lawful, authorized means.

## Known limitations

- The renderer currently displays a test triangle; it is a graphics smoke-test, not Minecraft rendering.
- The framebuffer class owns its attachment textures and must be closed while its OpenGL context is current.
- The resource registry is render-thread confined. Register and close GL objects on the context-owning thread.
- `glfwTerminate()` is called once by the launcher after the window and renderer have been closed.
- Actual compilation and GPU execution must be performed on the target machine; this archive creation does not prove that the build or runtime test passed.
