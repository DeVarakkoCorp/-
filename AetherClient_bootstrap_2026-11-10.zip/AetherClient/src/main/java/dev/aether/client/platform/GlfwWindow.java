package dev.aether.client.platform;

import org.lwjgl.glfw.GLFWFramebufferSizeCallback;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.system.MemoryUtil.NULL;

public final class GlfwWindow implements AutoCloseable {
    private final int width;
    private final int height;
    private final String title;
    private long handle;
    private int framebufferWidth;
    private int framebufferHeight;
    private GLFWFramebufferSizeCallback framebufferCallback;

    public GlfwWindow(int width, int height, String title) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Window dimensions must be positive");
        }
        this.width = width;
        this.height = height;
        this.title = title;
    }

    public void create() {
        if (handle != NULL) {
            throw new IllegalStateException("Window already created");
        }

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
        glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        long created = glfwCreateWindow(width, height, title, NULL, NULL);
        if (created == NULL) {
            throw new IllegalStateException("Failed to create GLFW window");
        }

        handle = created;
        int[] w = new int[1];
        int[] h = new int[1];
        glfwGetFramebufferSize(handle, w, h);
        framebufferWidth = w[0];
        framebufferHeight = h[0];

        framebufferCallback = GLFWFramebufferSizeCallback.create((window, newWidth, newHeight) -> {
            framebufferWidth = newWidth;
            framebufferHeight = newHeight;
        });
        glfwSetFramebufferSizeCallback(handle, framebufferCallback);

        glfwSetKeyCallback(handle, (window, key, scancode, action, mods) -> {
            if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
                glfwSetWindowShouldClose(window, true);
            }
        });
    }

    public long handle() {
        ensureCreated();
        return handle;
    }

    public boolean shouldClose() {
        ensureCreated();
        return glfwWindowShouldClose(handle);
    }

    public int framebufferWidth() {
        return framebufferWidth;
    }

    public int framebufferHeight() {
        return framebufferHeight;
    }

    private void ensureCreated() {
        if (handle == NULL) {
            throw new IllegalStateException("Window is not created");
        }
    }

    @Override
    public void close() {
        if (handle == NULL) {
            return;
        }
        glfwSetFramebufferSizeCallback(handle, null);
        if (framebufferCallback != null) {
            framebufferCallback.free();
            framebufferCallback = null;
        }
        glfwDestroyWindow(handle);
        handle = NULL;
    }
}
