package dev.aether.client.launcher;

import dev.aether.client.platform.GlfwWindow;
import dev.aether.client.rendering.opengl.OpenGLRenderer;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.system.MemoryUtil.NULL;

public final class AetherLauncher {
    private AetherLauncher() {}

    public static void main(String[] args) {
        GLFWErrorCallback errorCallback = GLFWErrorCallback.createPrint(System.err);
        errorCallback.set();

        GlfwWindow window = null;
        OpenGLRenderer renderer = null;
        boolean glfwInitialized = false;

        try {
            if (!glfwInit()) {
                throw new IllegalStateException("GLFW initialization failed");
            }
            glfwInitialized = true;

            window = new GlfwWindow(1280, 720, "Aether Client");
            window.create();

            glfwMakeContextCurrent(window.handle());
            glfwSwapInterval(1);
            GL.createCapabilities();

            renderer = new OpenGLRenderer();
            renderer.initialize();

            long previousNanos = System.nanoTime();
            while (!window.shouldClose()) {
                glfwPollEvents();

                long now = System.nanoTime();
                float deltaSeconds = Math.min((now - previousNanos) / 1_000_000_000.0f, 0.1f);
                previousNanos = now;

                int width = window.framebufferWidth();
                int height = window.framebufferHeight();
                if (width > 0 && height > 0) {
                    renderer.render(width, height, deltaSeconds);
                    glfwSwapBuffers(window.handle());
                }
            }
        } finally {
            if (renderer != null) {
                renderer.close();
            }
            if (window != null) {
                window.close();
            }
            if (glfwInitialized) {
                glfwTerminate();
            }
            errorCallback.free();
        }
    }
}
