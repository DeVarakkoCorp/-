package dev.aether.client.rendering;

public interface RenderTarget extends AutoCloseable {
    void bind();
    void unbind();
    int width();
    int height();
    void resize(int width, int height);
    @Override
    void close();
}
