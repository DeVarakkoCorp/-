package dev.aether.client.rendering.opengl;

import org.lwjgl.system.MemoryStack;

import java.nio.FloatBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public final class OpenGLRenderer implements AutoCloseable {
    private final Thread ownerThread = Thread.currentThread();
    private final GlResourceRegistry resources = new GlResourceRegistry(ownerThread);

    private ShaderProgram shader;
    private int vao;
    private int vbo;
    private boolean initialized;

    private static final String VERTEX_SHADER = """
            #version 330 core
            layout (location = 0) in vec2 position;
            layout (location = 1) in vec3 color;
            out vec3 vertexColor;
            void main() {
                gl_Position = vec4(position, 0.0, 1.0);
                vertexColor = color;
            }
            """;

    private static final String FRAGMENT_SHADER = """
            #version 330 core
            in vec3 vertexColor;
            out vec4 fragmentColor;
            void main() {
                fragmentColor = vec4(vertexColor, 1.0);
            }
            """;

    public void initialize() {
        checkThread();
        if (initialized) throw new IllegalStateException("Renderer already initialized");

        shader = resources.register(new ShaderProgram(VERTEX_SHADER, FRAGMENT_SHADER));

        float[] vertices = {
                -0.65f, -0.55f, 1.0f, 0.25f, 0.20f,
                 0.65f, -0.55f, 0.20f, 0.85f, 0.35f,
                 0.00f,  0.65f, 0.20f, 0.45f, 1.0f
        };

        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        if (vao == 0 || vbo == 0) {
            if (vbo != 0) glDeleteBuffers(vbo);
            if (vao != 0) glDeleteVertexArrays(vao);
            throw new IllegalStateException("Failed to allocate triangle buffers");
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {
            FloatBuffer data = stack.mallocFloat(vertices.length);
            data.put(vertices).flip();

            glBindVertexArray(vao);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferData(GL_ARRAY_BUFFER, data, GL_STATIC_DRAW);

            int stride = 5 * Float.BYTES;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0L);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 3, GL_FLOAT, false, stride, 2L * Float.BYTES);

            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glBindVertexArray(0);
        }

        initialized = true;
    }

    public void render(int framebufferWidth, int framebufferHeight, float deltaSeconds) {
        checkThread();
        if (!initialized) throw new IllegalStateException("Renderer is not initialized");
        if (framebufferWidth <= 0 || framebufferHeight <= 0) return;

        glViewport(0, 0, framebufferWidth, framebufferHeight);
        glClearColor(0.035f, 0.045f, 0.075f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        shader.bind();
        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glBindVertexArray(0);
        glUseProgram(0);
    }

    private void checkThread() {
        if (Thread.currentThread() != ownerThread) {
            throw new IllegalStateException("Renderer must be used on its OpenGL context thread");
        }
    }

    @Override
    public void close() {
        checkThread();
        if (vbo != 0) {
            glDeleteBuffers(vbo);
            vbo = 0;
        }
        if (vao != 0) {
            glDeleteVertexArrays(vao);
            vao = 0;
        }
        resources.close();
        initialized = false;
    }
}
