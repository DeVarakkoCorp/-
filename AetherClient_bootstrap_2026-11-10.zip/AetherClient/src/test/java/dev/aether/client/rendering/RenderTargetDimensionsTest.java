package dev.aether.client.rendering;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RenderTargetDimensionsTest {
    @Test
    void rejectsZeroAndNegativeDimensions() {
        assertThrows(IllegalArgumentException.class, () -> validate(0, 10));
        assertThrows(IllegalArgumentException.class, () -> validate(10, 0));
        assertThrows(IllegalArgumentException.class, () -> validate(-1, 10));
    }

    @Test
    void acceptsPositiveDimensions() {
        assertDoesNotThrow(() -> validate(2560, 1440));
    }

    private static void validate(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Dimensions must be positive");
        }
    }
}
